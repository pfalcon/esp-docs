var searchData=
[
  ['esp_5fnow_5frecv_5fcb_5ft',['esp_now_recv_cb_t',['../group__ESPNow__APIs.html#gadd5a6237e11ed8513c4956f6109730a7',1,'espnow.h']]],
  ['esp_5fnow_5fsend_5fcb_5ft',['esp_now_send_cb_t',['../group__ESPNow__APIs.html#ga5d05ff4fff6db81409e30f7e7e5d48c7',1,'espnow.h']]],
  ['espconn_5fconnect_5fcallback',['espconn_connect_callback',['../group__Espconn__APIs.html#gac2f5cc499f1d963723ed37d87a029a00',1,'espconn.h']]],
  ['espconn_5freconnect_5fcallback',['espconn_reconnect_callback',['../group__Espconn__APIs.html#ga06024aeff44004ddbdb7044b97676bba',1,'espconn.h']]],
  ['espconn_5frecv_5fcallback',['espconn_recv_callback',['../group__Espconn__APIs.html#ga5c93b1b8d3455a8f4fdeb35b064c4b0f',1,'espconn.h']]]
];
