var searchData=
[
  ['airkiss_5flan_5fpack',['airkiss_lan_pack',['../group__AirKiss__APIs.html#gab6bab3b00620928bca5e2adc0d2abd31',1,'airkiss.h']]],
  ['airkiss_5flan_5frecv',['airkiss_lan_recv',['../group__AirKiss__APIs.html#ga7545a7e75de00da0b22c232de602e092',1,'airkiss.h']]],
  ['airkiss_5fversion',['airkiss_version',['../group__AirKiss__APIs.html#gad2485fae7edd33913a96ae91fd277acd',1,'airkiss.h']]]
];
