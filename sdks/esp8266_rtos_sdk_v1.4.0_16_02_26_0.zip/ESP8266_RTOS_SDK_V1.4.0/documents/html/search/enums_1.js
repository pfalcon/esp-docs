var searchData=
[
  ['dhcp_5fstatus',['dhcp_status',['../group__Misc__APIs.html#ga9e40444d24f71f875b15136edec8fc47',1,'esp_misc.h']]],
  ['dhcps_5foffer_5foption',['dhcps_offer_option',['../group__Misc__APIs.html#ga47797d528afd74db93dd37a2c9207333',1,'esp_misc.h']]]
];
