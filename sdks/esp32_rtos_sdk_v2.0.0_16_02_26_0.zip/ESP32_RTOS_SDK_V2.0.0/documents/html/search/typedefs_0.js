var searchData=
[
  ['sc_5fcallback_5ft',['sc_callback_t',['../group___smartconfig___a_p_is.html#ga98fdb334fead4d1bd026b9ceee8c3db0',1,'smartconfig.h']]],
  ['scan_5fdone_5fcb_5ft',['scan_done_cb_t',['../group___station___a_p_is.html#ga953373c37a80c04a576ac03986a1ebfb',1,'esp_sta.h']]]
];
